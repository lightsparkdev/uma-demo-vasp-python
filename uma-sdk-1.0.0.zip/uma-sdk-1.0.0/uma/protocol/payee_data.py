# Copyright ©, 2022-present, Lightspark Group, Inc. - All Rights Reserved
from typing import Any, Dict

PayeeData = Dict[str, Any]

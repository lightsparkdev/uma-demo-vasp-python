#!/usr/bin/env python3

import setuptools

setuptools.setup(include_package_data=True)
